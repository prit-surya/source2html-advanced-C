#include <stdio.h>
#include <string.h>
#include "s2html_event.h"

pevent_t *get_parser_event(FILE *fp) {
    static pevent_t event;
    char buffer[PEVENT_DATA_SIZE];
    event.type = PEVENT_NULL;
    event.length = 0;

    if (fgets(buffer, PEVENT_DATA_SIZE, fp) == NULL) {
        event.type = PEVENT_EOF;
        return &event;
    }

    if (buffer[0] == '#') {
        event.type = PEVENT_PREPROCESSOR_DIRECTIVE;
        strcpy(event.data, buffer);
    } else if (strstr(buffer, "//")) {
        event.type = PEVENT_SINGLE_LINE_COMMENT;
        strcpy(event.data, buffer);
    } else if (strstr(buffer, "\"")) {
        event.type = PEVENT_STRING;
        strcpy(event.data, buffer);
    } else if (strstr(buffer, "int") || strstr(buffer, "float") || strstr(buffer, "return")) {
        event.type = PEVENT_RESERVE_KEYWORD;
        strcpy(event.data, buffer);
        event.property = RES_KEYWORD_DATA;
    } else if (strpbrk(buffer, "0123456789")) {
        event.type = PEVENT_NUMERIC_CONSTANT;
        strcpy(event.data, buffer);
    } else if (strstr(buffer, "<") && strstr(buffer, ">")) {
        event.type = PEVENT_HEADER_FILE;
        strcpy(event.data, buffer);
    } else {
        strcpy(event.data, buffer);
    }
    event.length = strlen(event.data);
    return &event;
}
 
