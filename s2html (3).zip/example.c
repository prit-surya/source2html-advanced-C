#include <stdio.h>  // Standard header file

#define PI 3.14159  // Define a constant

int main() {
    // Declare variables
    float radius = 5.0;
    float area;

    // Calculate the area of the circle
    area = PI * radius * radius;

    // Print the result
    printf("The area of the circle is: %.2f\n", area);

    return 0;
}

