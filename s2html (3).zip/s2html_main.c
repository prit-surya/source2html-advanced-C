/**************************************
 Name :-        Pritesh suryawanshi
 Date :-        10/9/2024
 Description :- Source 2 html project
 sample input :- ./s2html example.c
                 xdg-open example.c
***************************************/
#include <stdio.h>
#include "s2html_event.h"
#include "s2html_conv.h"

int main (int argc, char *argv[]) {
    FILE *sfp, *dfp;  // source and destination file descriptors
    pevent_t *event;
    char dest_file[100];

    if (argc < 2) {
        printf("\nError! Please enter the file name.\n");
        printf("Usage: <executable> <file name>\n");
        return 1;
    }

    /* Open the source file */
    if (NULL == (sfp = fopen(argv[1], "r"))) {
        printf("Error! File %s could not be opened\n", argv[1]);
        return 2;
    }

    /* Set output file name */
    sprintf(dest_file, "%s.html", argv[1]);

    /* Open the destination file */
    if (NULL == (dfp = fopen(dest_file, "w"))) {
        printf("Error! Could not create %s output file\n", dest_file);
        return 3;
    }

    /* Write HTML starting Tags */
    html_begin(dfp, HTML_OPEN);

    /* Read from the source file, convert into HTML, and write to the destination file */
    do {
        event = get_parser_event(sfp);
        source_to_html(dfp, event);
    } while (event->type != PEVENT_EOF);

    /* Write HTML ending Tags */
    html_end(dfp, HTML_CLOSE);

    printf("\nOutput file %s generated\n", dest_file);

    /* Close files */
    fclose(sfp);
    fclose(dfp);

    return 0;
}

